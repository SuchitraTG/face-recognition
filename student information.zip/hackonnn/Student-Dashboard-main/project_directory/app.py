from flask import Flask, render_template, request, jsonify, send_from_directory, redirect, url_for
import cv2
import os
from datetime import datetime

app = Flask(__name__)

# Directory to save captured images
CAPTURED_IMAGES_DIR = 'captured_images'
KNOWN_IMAGES_DIR = 'known_images'
os.makedirs(CAPTURED_IMAGES_DIR, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/capture', methods=['POST'])
def capture():
    try:
        # Initialize the webcam
        cap = cv2.VideoCapture(0)

        if not cap.isOpened():
            return jsonify({"error": "Could not open webcam."}), 500

        # Read a frame from the webcam
        ret, frame = cap.read()

        if not ret:
            cap.release()
            return jsonify({"error": "Could not read frame from webcam."}), 500

        # Generate a unique filename based on the current timestamp
        filename = f'captured_image_{datetime.now().strftime("%Y%m%d_%H%M%S%f")}.jpg'
        filepath = os.path.join(CAPTURED_IMAGES_DIR, filename)

        # Save the captured image
        cv2.imwrite(filepath, frame)
        cap.release()
        
        # Redirect to the recognition page after capturing the image
        return redirect(url_for('recognition'))

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/recognition')
def recognition():
    # Perform recognition process here
    # This route will render the recognition HTML page
    return render_template('recognition.html')

@app.route('/images/<filename>')
def images(filename):
    return send_from_directory(CAPTURED_IMAGES_DIR, filename)

if __name__ == "__main__":
    app.run(debug=True)
