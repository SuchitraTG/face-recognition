# simple-face-recognition
This is very simple own face recognition program built using a simple face_recognition command line tool. This face recognition model is built using dlib’s state-of-the-art face recognition built with deep learning.

# USE CASES
1. Unlock Phones
2. Find Missing Persons
3. Identify People on Social Media Platforms
